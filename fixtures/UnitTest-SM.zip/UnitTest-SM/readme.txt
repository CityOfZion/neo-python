Please read following guideline: https://neo-python.readthedocs.io/en/latest/tests.html


useful commands which are use frequently during test mode:

rm -rf ~/.neopython/Chains/unittest
rm -rf ~/.neopython/Chains/unittest_notif

docker pull dautt/neo-privnet-unittest:v0.0.xx
docker run --rm -d --name neo-privatenet -p 20333-20336:20333-20336/tcp -p 30333-30336:30333-30336/tcp cityofzion/neo-

python prompt.py -u

open wallet neo-privnet.wallet 
pwd=coz
wallet rebuild

build /root/.neopython/Chains/UnitTest-SM/contracts/sample2.py test 070202 02 False False add 1 2
import contract /root/.neopython/Chains/UnitTest-SM/contracts/sample2.avm 070202 02 False False

deploy NEP5:
https://blog.ovalerio.net/archives/1478

# nex/token.py
TOKEN_NAME = 'Example ICO Token'
TOKEN_SYMBOL = 'EIT'
TOKEN_OWNER = b'{{your_wallet_script_hash}}'

build /home/dau/.neopython/UnitTest/UnitTest-SM/contracts/neo-ico-template/ico_template.py 0710 05 True False False
import contract /home/dau/.neopython/UnitTest/UnitTest-SM/contracts/neo-ico-template/ico_template.avm 0710 05 True False False

[Contract Name] > test NEX Template V4                                          
[Contract Version] > test                                                       
[Contract Author] > dauTT                                                       
[Contract Email] >                                                              
[Contract Description] > ico_template

testinvoke {{hash}} deploy []
import token {hash}

contract search test

send Neo
send c56f33fc6ecfcd0c225c4ab356fee59390af8560be0e930faebe74a6daff7c9b AXpNr3SDfLXbPHNdqxYeHK5cYpKMHZxMZ9 10000 --from-address=AK2nJJpJr6o664CWJKi1QRXjqeic2

send token:
wallet tkn_send b9fbcff6e50fd381160b822207231233dd3c56c2 AXpNr3SDfLXbPHNdqxYeHK5cYpKMHZxMZ9 ANLeAruhbuBRyb8CFn5H31y9a2c84vpWb3 10

